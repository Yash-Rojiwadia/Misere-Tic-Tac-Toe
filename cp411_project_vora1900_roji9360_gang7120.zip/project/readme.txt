
Title: 2D Misere Tic-Tac-Toe 
Team: Jay Vora, Yash Rojiwadia, Pranav Gangwani
WorkID: cp411-project
Statement: We claim that the enclosed project submission is our team work.  

Fill in the self-evaluation in each grading item of the following evaluation grid.
Symbol: R -- Project requirement
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid

Item_ID [self-evaluation/total/marker-evaluation] Description


1 Proposal

R1.1 [5/5/*] Application problem description

R1.2 [5/5/*] Creativity/new features

R1.3 [5/5/*] Design consideration

R1.4 [5/5/*] Milestones and schedule

R1.5 [5/5/*] References

R1.6 [5/5/*] Writing of the proposal

2 Design & implementation

R2.1 [30/30/*] Problem solving and algorithms

R2.2 [30/30/*] Completion of the project

R2.3 [20/20/*] New features

R2.4 [20/20/*] Program design and organization

3 Delivery

R3.1 [10/10/*] Presentation & demonstration

R3.2 [5/5/*] Documentation

R3.3 [5/5/*] Submission packaging

Total: [150/150/*]
